document.write("<h2>1. Create a simple for loop that sums all the numbers between x and y. Have it console log the final sum.</h2>");
document.write("<b>(Standalone Function:)</b><br>");
document.write("function Sum( x,y ) {<br>");
document.write("var sum = 0;<br>")
document.write("for ( var i = x; i <= y; i++ )<br>");
document.write("{<br>");
document.write("sum = sum + i;<br>");
document.write("}<br>");
document.write("console.log(sum);<br>");
document.write("}<br>");
document.write("Sum(1,10); //result is 55 (1+2+3+...10)<br><br>");

document.write("<b>(Anonymous Function:)</b><br>");
document.write("var sum = function( x,y ) {<br>");
document.write("var sum = 0;<br>")
document.write("for ( var i = x; i <= y; i++ )<br>");
document.write("{<br>");
document.write("sum = sum + i;<br>");
document.write("}<br>");
document.write("console.log(sum);<br>");
document.write("}<br>");
document.write("Sum(1,10); //result is 55 (1+2+3+...10)<br><br>");

document.write("<b>(part of a Object1 method:)</b><br>");
document.write("var Object1 = {<br>");
document.write("sum function(x,y) {<br>");
document.write("var sum = 0;<br>");
document.write("for(var i = x; i <= y; i++) {<br>");
document.write("sum = sum + i;<br>");
document.write("}<br>");
document.write("console.log(sum);<br>");
document.write("}<br>");
document.write("}<br>");
document.write("Object1.sum(1,10);<br>");

document.write("<h2>2. Write a loop that will go through an array, find the minimum value, and then return it</h2>");
document.write("<b>(Standalone Function:)</b><br>");
document.write("function findMin(array){<br>");
document.write("var min = x[0];<br>");
document.write("for (var i = 0; i < array.length; i++){<br>");
document.write("if (min > array[i]){<br>");
document.write("min = array[i];<br>");
document.write("}<br>");
document.write("}<br>");
document.write("return min<br>");
document.write("findMin([55,44,66,22,11,88,99]);<br><br>");

document.write("<b>(Anonymous Function:)</b><br>");
document.write("var findMin = function(array){<br>");
document.write("var min = x[0];<br>");
document.write("for (var i = 0; i < array.length; i++){<br>");
document.write("if (min > array[i]){<br>");
document.write("min = array[i];<br>");
document.write("}<br>");
document.write("}<br>");
document.write("return min<br>");
document.write("findMin([55,44,66,22,11,88,99]);<br><br>");

document.write("<b>(part of a Object1 method:)</b><br>");
document.write("var Object1 = {<br>");
document.write("findMin: function(x) {<br>");
document.write("var min = x[0];<br>");
document.write("for (var i = 0; i < x.length; i++) {<br>");
document.write("if (min > x[i]) {<br>");
document.write("min = x[i];<br>");
document.write("}<br>");
document.write("}<br>");
document.write("return min<br>");
document.write("}<br>");
document.write("}<br>");
document.write("Object1.findMin([55,44,66,22,11,88,99]);<br>");

document.write("<h2>3. Write a loop that will go through an array, find the average of all of the values, and then return it</h2><br>");
document.write("<b>(Standalone Function:)</b><br>");
document.write("function findAverage(array){<br>");
document.write("var sum = 0;<br>");
document.write("var average = 0;<br>");
document.write("for (var i = 0; i < array.length; i++){<br>");
document.write("sum = sum + array[i];<br>")
document.write("}<br>");
document.write("average = sum / array.length;<br>");
document.write("return average;<br>");
document.write("}<br>");
document.write("findAverage([1,2,3,4,5,6,7,8,9,10]);<br><br>");

document.write("<b>(Anonymous Function:)</b><br>");
document.write("var findAverage = function(array){<br>");
document.write("var sum = 0;<br>");
document.write("var average = 0;<br>");
document.write("for (var i = 0; i < array.length; i++){<br>");
document.write("sum = sum + array[i];<br>")
document.write("}<br>");
document.write("average = sum / array.length;<br>");
document.write("return average;<br>");
document.write("}<br>");
document.write("findAverage([1,2,3,4,5,6,7,8,9,10]);<br><br>");

document.write("<b>(part of a Object1 method:)</b><br>");
document.write("var Object1 = {<br>");
document.write("findAverage: function(array) { <br>");
document.write("var sum = 0;<br>");
document.write("var average = 0;<br>");
document.write("for (var i = 0; i < array.length; i++) {<br>");
document.write("sum = sum + array[i];<br>");
document.write("}<br>");
document.write("}<br>");
document.write("average = sum / array.length;<br>");
document.write("return average;<br>");
document.write("}<br>");
document.write("Object1.findAverage([1,2,3,4,5,6,7,8,9,10])<br><br>");

document.write("<h2>Create a javascript object called person with the following properties/methods</h2><br>");
document.write("<b>name</b> - set this as 'Trey' or your own name<br>");
document.write("<b>distance_travelled</b> - set this initially as zero<br>");
document.write("<b>say_name</b> - should alert the object's name property<br>");
document.write("<b>say_something</b> - have it accept a parameter. It should then say for example 'Trey says 'I am cool'' if you pass 'I am cool' as an argument to this method.<br>");
document.write("<b>walk</b> - have it alert for example 'Trey is walking' and increase distance_travelled by 3<br>");
document.write("<b>run</b> - have it alert for example 'Trey is running' and increase distance_travelled by 10<br>");
document.write("<b>crawl</b> - have it alert for example 'Trey is crawling' and increase distance_travelled by 1<br><br>");
document.write("var person = {<br>");
document.write("name: 'Vincent',<br>");
document.write("occupation: 'engineer in residence',<br>");
document.write("say_name: function() {<br>");
document.write("var distance_travelled = 0;<br>");
document.write("console.log('Hi, my name is', person.name);<br>");
document.write("}<br>");
document.write("}<br>");
document.write("person.say_something = function(argument) {<br>");
document.write("console.log(person.name +' says '+ argument);<br>");
document.write("}<br>");
document.write("person.walk = function() {<br>");
document.write("distance_travelled =+ 3;<br>");
document.write("console.log(person.name +' is walking');<br>");
document.write("}<br>");
document.write("person.run = function() {<br>");
document.write("distance_travelled =+10;<br>");
document.write("console.log(person.name + ' is running');<br>");
document.write("}<br>");
document.write("person.crawl = function() {<br>");
document.write("distance_travelled =+ 1;<br>");
document.write("console.log(person.name + ' is crawling');<br>");
document.write("}<br>");
document.write("person.say_name();<br>");
document.write("person.say_something('I am cool');<br>");
document.write("person.walk();<br>");
document.write("person.run();<br>");
document.write("person.crawl();<br>");

